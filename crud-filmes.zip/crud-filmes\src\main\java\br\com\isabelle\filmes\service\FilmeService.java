package br.com.isabelle.filmes.service;

import br.com.isabelle.filmes.model.Filme;
import br.com.isabelle.filmes.repository.FilmeRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FilmeService {
    private final FilmeRepository repository;

    public FilmeService(FilmeRepository repository) { this.repository = repository; }
    public List<Filme> listarTodos() { return repository.findAll(); }
    public List<Filme> buscarPorTitulo(String titulo) {
        return (titulo == null || titulo.isBlank()) ? listarTodos() : repository.findByTituloContainingIgnoreCase(titulo.trim());
    }
    public Filme buscarPorId(Long id) { return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Filme não encontrado: " + id)); }
    public Filme salvar(Filme filme) { return repository.save(filme); }
    public void excluir(Long id) { repository.deleteById(id); }
}
