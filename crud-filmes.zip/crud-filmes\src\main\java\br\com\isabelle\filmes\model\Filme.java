package br.com.isabelle.filmes.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Filme {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Informe o título.")
    @Size(max = 100, message = "O título deve ter até 100 caracteres.")
    private String titulo;

    @NotBlank(message = "Informe o gênero.")
    @Size(max = 50, message = "O gênero deve ter até 50 caracteres.")
    private String genero;

    @NotNull(message = "Informe uma nota de 0 a 10.")
    @DecimalMin(value = "0.0", message = "A nota mínima é 0.")
    @DecimalMax(value = "10.0", message = "A nota máxima é 10.")
    private Double nota;

    public Filme() { }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }
    public Double getNota() { return nota; }
    public void setNota(Double nota) { this.nota = nota; }
}
