USE crud_filmes;

-- Execute depois que a aplicação criar a tabela filme.
INSERT INTO filme (titulo, genero, nota) VALUES
('O Exorcista', 'Terror', 9.0),
('Invocação do Mal', 'Terror', 8.5),
('A Freira', 'Terror', 7.5);
